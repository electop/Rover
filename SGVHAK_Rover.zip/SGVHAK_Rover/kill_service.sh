sudo lsof -t -i tcp:5000 | xargs kill -9
