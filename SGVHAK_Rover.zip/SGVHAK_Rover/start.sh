export FLASK_APP=SGVHAK_Rover
#export FLASK_DEBUG=1
#flask run
flask run --host=0.0.0.0 &
